# a/A Ruby Algorithms Study Group

#### [Guest Lecture 1: Dynamic Programming with Matrices](guest1_dynamic_programming.md) | [Solutions](guest1_solutions.md)
