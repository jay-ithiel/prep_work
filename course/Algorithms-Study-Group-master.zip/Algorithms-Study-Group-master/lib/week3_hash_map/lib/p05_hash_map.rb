require_relative 'p02_hashing'
require_relative 'p04_linked_list'

class HashMap
  attr_reader :count
  def initialize(size = 8)
  end

  def include?(key)
  end

  def set(key, val)
  end

  def get(key)
  end

  def delete(key)
  end

  def [](key)
  end

  def []=(key, val)
  end

  def each
  end

  private

  def resize!
  end
end
