require_relative 'p02_hashing'

class HashSet
  attr_reader :count

  def initialize(size = 8)
  end

  def insert(key)
  end

  def include?(key)
  end

  def remove(key)
  end

  private

  def resize!
  end
end
