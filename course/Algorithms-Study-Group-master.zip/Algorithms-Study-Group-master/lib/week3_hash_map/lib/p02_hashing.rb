class Fixnum
  # Fixnum#hash already implemented for you
end

class Array
  def hash
  end
end

class String
  def hash
  end
end

class Hash
  def hash
  end
end
