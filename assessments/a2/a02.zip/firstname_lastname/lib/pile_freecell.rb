class FreeCell < Pile
  def to_s
    empty? ? "[  ]" : "[#{top_card}]"
  end

  def valid_move?(card)
  end
end
