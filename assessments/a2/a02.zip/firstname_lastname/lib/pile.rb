class Pile
  attr_reader :cards

  def initialize(cards = [])
  end

  def empty?
  end

  def draw
  end

  def count
  end

  def top_card
  end

  # implement this method in each of the Pile subclasses
  def valid_move?(card)
    raise "Not yet implemented!"
  end

  def <<(card)
  end
end
