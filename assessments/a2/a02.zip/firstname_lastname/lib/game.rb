class Game
  attr_reader :free_cells, :foundations, :tableau

  def initialize
    @free_cells = Array.new(4) { FreeCell.new }
    @foundations = Foundation.all_foundations
    @tableau = Array.new(8) { Tableau.new }
    deal_tableau
    # ...
  end

  def deal_tableau
  end

  def move!(from_pile, to_pile)
  end

  def move(from_pile, to_pile)
  end

  def undo_move
  end

  def valid_move?(from_pile, to_pile)
  end

  def won?
  end
end
